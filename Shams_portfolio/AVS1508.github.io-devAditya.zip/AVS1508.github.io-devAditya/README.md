# <a href="https://www.adityavsingh.com" target="_blank">My Personal Website</a>

[![Repository Status](https://img.shields.io/badge/Repository%20Status-Maintained-dark%20green.svg)](https://github.com/AVS1508/AVS1508.github.io/)
[![Website Status](https://img.shields.io/badge/Website%20Status-Online-green)](https://www.adityavsingh.com)
[![Author](https://img.shields.io/badge/Author-Aditya%20Vikram%20Singh-blue.svg)](https://www.linkedin.com/in/AVS1508/)
[![Latest Release](https://img.shields.io/badge/Latest%20Release-22%20September%202021-yellow.svg)](https://github.com/AVS1508/AVS1508.github.io/commit/master)

 <p align="justify">This website serves as an online résumé and displays my web presence, story, work experience, education, projects, achievements, and contact information. It was created using ReactJS, Bootstrap, and CSS.</p>

![Personal Résume Website](https://raw.githubusercontent.com/AVS1508/AVS1508.github.io/devAditya/website-view.webp)

Please hit me up at avsingh@umass.edu if you have any feedback or ideas for the website. Leave a :star: &nbsp;if you like it!
